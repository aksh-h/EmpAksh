﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace EmployeeManagement.Models
{
    public class Designation
    {
        [Required(ErrorMessage = "DesignationId is required.")]
   
        public int DesignationId { get; set; }

        [Required(ErrorMessage = "Designation Name is required.")]
        [StringLength(20, ErrorMessage = "Designation Name cannot exceed 20 chars.")]
        [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Only Alphabets are allowed.")]
        public string DesignationName{ get; set; }
        


        [Required(ErrorMessage = "Status is required.")]
        public bool Status { get; set; }
    }
}
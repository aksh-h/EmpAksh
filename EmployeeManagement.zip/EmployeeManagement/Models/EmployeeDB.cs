﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EmployeeManagement.Models
{
    public class EmployeeDB
    {
        // const string defaultconnectionString = "Data Source=YAMUNA\\SQLDEV2016;Initial Catalog=OfficeManagement;Integrated Security=True";
        string cs = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;

        //Return list of all Employees
        public List<Empl> ListAll()
        {
            List<Empl> lst = new List<Empl>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SelectEmployee", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    lst.Add(new Empl
                    {
                        EId = Convert.ToInt32(rdr["EId"]),
                        EName = rdr["EName"].ToString(),
                        DesignationName = rdr["DesignationName"].ToString(),
                        Email = rdr["Email"].ToString(),
                        PhoneNo = rdr["PhoneNo"].ToString(),
                        Status = Convert.ToBoolean(rdr["Status"].ToString()),
                        ManagerId =Convert.ToInt32(rdr["ManagerId"].ToString()),
                    });
                }
                return lst;
            }
        }
        //Method for Adding an Employee
        public int Add(Empl emp)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("InsertUpdateEmploye", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@EId", emp.EId);
                com.Parameters.AddWithValue("@EName", emp.EName);
                com.Parameters.AddWithValue("@DesName", emp.DesignationName);
                com.Parameters.AddWithValue("@Email", emp.Email);
                com.Parameters.AddWithValue("@PhoneNo", emp.PhoneNo);
                com.Parameters.AddWithValue("@Status", emp.Status);
                com.Parameters.AddWithValue("@ManagerId", emp.ManagerId);
                com.Parameters.AddWithValue("@Action", "Insert");
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        //Method for Updating Employee record
        public int Update(Empl emp)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("InsertUpdateEmploye", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@EId", emp.EId);
                com.Parameters.AddWithValue("@EName", emp.EName);
                com.Parameters.AddWithValue("@DesName", emp.DesignationName);
                com.Parameters.AddWithValue("@Email", emp.Email); 
                com.Parameters.AddWithValue("@PhoneNo", emp.PhoneNo);
                com.Parameters.AddWithValue("@Status", emp.Status);
                com.Parameters.AddWithValue("@ManagerId", emp.ManagerId);
                com.Parameters.AddWithValue("@Action", "Update");
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        //Method for Deleting an Employee
        public int Delete(int ID)
        {
            int i;
            using (SqlConnection con = new SqlConnection(cs))
            {
                con.Open();
                SqlCommand com = new SqlCommand("DeleteEmployee", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@EId", ID);
                i = com.ExecuteNonQuery();
            }
            return i;
        }

        public List<string> FlowChart(int id)
        {
            EmployeeDB data = new EmployeeDB();
            SqlCommand com = new SqlCommand();
            SqlConnection con = new SqlConnection(cs);
            com.Connection = con;
            com.CommandText = "ProjectFlow";
            com.CommandType = System.Data.CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@Pid", id);
            return data.ProjectInfo(com);

        }


        public List<string> ProjectInfo(SqlCommand com)
        {
            List<string> EmpList = new List<string>();
            using (SqlConnection con = new SqlConnection(cs))
            {
                try
                {
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = com;

                    DataSet dataSet = new DataSet();
                    adapter.Fill(dataSet, "ProjectInfo");
                    EmpList.Add(dataSet.Tables["ProjectInfo"].Rows[0][0].ToString());
                    EmpList.Add(dataSet.Tables["ProjectInfo"].Rows[0][2].ToString());
                    //MemoryStream ms = new MemoryStream((byte[])dataSet.Tables["ProjectInfo"].Rows[0][4]);


                    //EmpList.Add(Convert.ToBase64String(ms.ToArray()));
                    for (int i = 0; i < dataSet.Tables["projectinfo"].Rows.Count; i++)
                    {
                        //ms = new memorystream((byte[])dataset.tables["projectinfo"].rows[i][2]);
                        EmpList.Add(dataSet.Tables["projectinfo"].Rows[i][1].ToString());
                        //EmpList.add(Convert.Tobase64string(ms.toarray()));
                    }
                }
                catch (Exception E)
                {
                    throw E;
                }
            }
            return EmpList;








        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeManagement.Models
{
    public class Empl
    { 
        public int EId { get; set; }
        public string EName { get; set; }
        //public List<SelectListItem> DesignationName { get; set; }
        public string DesignationName { get; set; }
        public string Email { get; set; }
        public string PhoneNo { get; set; }
        public bool Status { get; set; }
         public int ManagerId { get; set; }
        public string ReportingTo { get; internal set; }

        
    }
}
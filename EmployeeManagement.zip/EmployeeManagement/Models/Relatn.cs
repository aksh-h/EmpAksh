﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeManagement.Models
{
    public class Relatn
    {
        public int RelationId { get; set; }
        public Nullable<int> PId { get; set; }
        public Nullable<int> EId { get; set; }
        public Nullable<int> RId { get; set; }
        public string EName { get; internal set; }
        public string PName { get; internal set; }
        public string Description { get; internal set; }
        public string Client { get; internal set; }
        public string Technology { get; internal set; }
        public string StartDate { get; internal set; }
        public string EndDate { get; internal set; }
        public bool Status { get; internal set; }
        public IEnumerable<SelectListItem> ProjectList { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EmployeeManagement.Models
{
    public class DesignationDataAccess
    {
        SqlConnection connection;
        const string defaultconnectionString = "Data Source=YAMUNA\\SQLDEV2016;Initial Catalog=OfficeManagement;Integrated Security=True";
        public DesignationDataAccess()
        {
            var connStr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
            if (string.IsNullOrEmpty(connStr)) connStr = defaultconnectionString;
            connection = new SqlConnection(connStr);
        }

        public IEnumerable<Designation> GetDesignations()
        {
            string sql = "SELECT * FROM Designation";
            List<Designation> designationList = new List<Designation>();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sql;
            SqlDataReader reader = null;

            try
            {
                connection.Open();

                reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    designationList.Add(new Designation
                    {
                        DesignationId = Convert.ToInt32("0" + reader["DesignationId"].ToString()),
                        DesignationName = reader["DesignationName"].ToString(),
                        Status = Convert.ToBoolean(reader["Status"].ToString())
                    });
                }
            }
            catch (Exception) { throw; }
            finally
            {
                if (reader != null) if (!reader.IsClosed) reader.Close();
                if (connection.State != ConnectionState.Closed) connection.Close();
            }
            return designationList;
        }

        public Designation GetDesignation(int designationId)
        {
            string sql = "SELECT * FROM Designation";
            sql += " WHERE DesignationId=@DesId";
            Designation designationObj = new Designation();
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddWithValue("@DesId", designationId);
            SqlDataReader reader = null;

            try
            {
                connection.Open();
                reader = command.ExecuteReader(CommandBehavior.CloseConnection);
                while (reader.Read())
                {
                    designationObj = new Designation
                    {
                        DesignationId = Convert.ToInt32("0" + reader["DesignationId"].ToString()),
                        DesignationName = reader["DesignationName"].ToString(),
                        Status = Convert.ToBoolean(reader["Status"].ToString())
                    };
                }
            }
            catch (Exception) { throw; }
            finally
            {
                if (reader != null) if (!reader.IsClosed) reader.Close();
                if (connection.State != ConnectionState.Closed) connection.Close();
            }
            return designationObj;
        }

        public void CreateDesignation(Designation item, char createOrUpdate = 'c')
        {
            string sql = string.Empty;
            if (createOrUpdate == 'c')
            {
                sql = " INSERT INTO Designation(DesignationId,DesignationName,Status) ";
                sql += " VALUES(@DesId,@DesName,@Status) ";
            }
            else if (createOrUpdate == 'U')
            {
                sql = " UPDATE Designation SET DesignationName=@DesName, ";
                sql += " Status=@status WHERE DesignationId=@DesId ";
            }
            SqlCommand command = connection.CreateCommand();
            command.CommandText = sql;
            command.Parameters.AddWithValue("@DesId", item.DesignationId);
            command.Parameters.AddWithValue("@DesName", item.DesignationName);
            command.Parameters.AddWithValue("@Status", item.Status);
           
            //if (createOrUpdate == 'U')
            //command.Parameters.AddWithValue("@DesId", item.DesignationId);
            
            try
            {
                connection.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex) { throw ex; }
            finally
            {
                if (connection.State != ConnectionState.Closed) connection.Close();
            }

        }

        //public void DeleteDesignation(int Id)
        //{
        //    if (Id > 0)
        //    {

        //        SqlCommand command = new SqlCommand();
        //        command.Connection = connection;

        //        command.Parameters.AddWithValue("@DesId", Id);
        //        try
        //        {
        //            connection.Open();
        //            command.ExecuteNonQuery();
        //        }
        //        catch (SqlException sqle)
        //        {
        //            throw sqle;
        //        }
        //        catch (Exception)
        //        {
        //            throw;
        //        }
        //        finally
        //        {
        //            connection.Close();
        //        }
        //    }
        //}


        public int DeleteDesignation(int ID)
        {
            int i;
            using (SqlConnection con = new SqlConnection(defaultconnectionString))
            {
                con.Open();
                SqlCommand com = new SqlCommand("Deletedesignation",con);
                com.Connection = con;
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@DesId", ID);
                i = com.ExecuteNonQuery();
               //i = (int)com.ExecuteScalar();
            
            }
            return i;
        }
        
    }
}
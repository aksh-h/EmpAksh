﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EmployeeManagement.Infrastructure
{
    public class DesignationRepository : IRepository<Designation, int>
    {
        DesignationDataAccess dataAccess;
        public DesignationRepository()
        {
            dataAccess = new DesignationDataAccess();
        }
        public void CreateNew(Designation item)
        {
            dataAccess.CreateDesignation(item: item, createOrUpdate: 'c');
        }

        public void Delete(int identity)
        {

            dataAccess.DeleteDesignation(identity);
        }

        public IQueryable<Designation> GetAll()
        {
            return dataAccess.GetDesignations().AsQueryable();
        }

        public Designation GetDetails(int identity)
        {
            return dataAccess.GetDesignation(designationId: identity);
        }

        public void Update(Designation item)
        {
            dataAccess.CreateDesignation(item: item, createOrUpdate: 'U');
        }
    }
}
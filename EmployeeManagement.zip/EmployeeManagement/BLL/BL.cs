﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace EmployeeManagement.BLL
{
    public class BL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ToString());
        
        string constr = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
        

        public List<Proj> PopulateProjects()
        {
            List<Proj> projects = new List<Proj>();
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "SELECT PName, PId FROM Project";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    using (SqlDataReader sdr = cmd.ExecuteReader())
                    {
                        while (sdr.Read())
                        {
                            projects.Add(new Proj
                            {
                                PName = sdr["PName"].ToString(),
                                PId = Convert.ToInt32(sdr["PId"])
                            });
                        }
                    }
                    con.Close();
                }
            }
            return projects;
        }


        private Relation GetProjectDetailsFromReader(SqlDataReader reader)
        {
            Relation p = new Relation();
            p.EId = int.Parse(reader["EId"].ToString());
            p.EName = reader["EName"].ToString();
            p.PName = reader["PName"].ToString();
            p.Description = reader["Description"].ToString();
            p.Client = reader["Client"].ToString();
            p.Technology = reader["Technology"].ToString();
            p.StartDate =reader["StartDate"].ToString();
            p.EndDate = reader["EndDate"].ToString();
            p.Status = Convert.ToBoolean(reader["Status"].ToString());
      
            return p;
        }
        public List<Relation> GetProjectDetails(int id)
        {
            List<Relation> list = new List<Relation>();
            SqlConnection con = new SqlConnection(constr);
            Relation obj = new Relation();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "usp_SelectProjectDetails";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@PId", id);
            SqlDataReader reader = null;
            try
            {
                con.Open();
                reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    obj = GetProjectDetailsFromReader(reader);
                    list.Add(obj);
                }
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                if (!reader.IsClosed)
                    reader.Close(); con.Close();
            }
            return list;  
        }
        internal Empl GetEmployee(int id)
        {
            Empl emp = new Empl();
            SqlConnection con = new SqlConnection(constr);
           
                    //string query = "Employee_detailss";
                    
                    //cmd.Connection = con;
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Employee_detailss",con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@EId", id);
                    SqlDataReader sdr = cmd.ExecuteReader();
                    {
                        while (sdr.Read())
                        {
                           emp.EId = Convert.ToInt32(sdr["EId"].ToString());
                           emp.EName = sdr["EName"].ToString();
                          
                           emp.DesignationName = sdr["DesignationName"].ToString();
                          
                           emp.Email = sdr["Email"].ToString();
                           emp.PhoneNo = sdr["PhoneNo"].ToString();
                           
                           emp.ReportingTo = sdr["ReportingTo"].ToString();
                        };
                    }
                    con.Close();
                
            
           
            return emp;
        }


        public List<Proj> ListAll()
        {
            List<Proj> lst = new List<Proj>();
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand com = new SqlCommand("SelectProject", con);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    lst.Add(new Proj
                    {
                        PId = Convert.ToInt32(rdr["PId"]),
                        PName = rdr["PName"].ToString(),
                        Description = rdr["Description"].ToString(),
                        Client = rdr["Client"].ToString(),
                        Technology = rdr["Technology"].ToString(),
                       //StartDate = Convert.ToDateTime(rdr["StartDate"].ToString()),
                       // EndDate = Convert.ToDateTime( rdr["EndDate"].ToString()),
                        Status = Convert.ToBoolean(rdr["Status"].ToString()),
                       
                    });
                }
                return lst;
            }
        }

        public int Add(Proj p)
        {
            int i;
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand com = new SqlCommand("InsertUpdateProject", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@PId", p.PId);
                com.Parameters.AddWithValue("@PName", p.PName);
                com.Parameters.AddWithValue("@Desc", p.Description);
                com.Parameters.AddWithValue("@Client", p.Client);
                com.Parameters.AddWithValue("@Technology", p.Technology);
                //com.Parameters.AddWithValue("@StartDate", p.StartDate);
                //com.Parameters.AddWithValue("@EndDate", p.EndDate);
                com.Parameters.AddWithValue("@Status", p.Status);


                com.Parameters.AddWithValue("@Action", "Insert");
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        //Method for Updating Employee record
        public int Update(Proj p)
        {
            int i;
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand com = new SqlCommand("InsertUpdateProject", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@PId", p.PId);
                com.Parameters.AddWithValue("@PName", p.PName);
                com.Parameters.AddWithValue("@Desc", p.Description);
                com.Parameters.AddWithValue("@Client", p.Client);
                com.Parameters.AddWithValue("@Technology", p.Technology);
                //com.Parameters.AddWithValue("@StartDate", p.StartDate);
                //com.Parameters.AddWithValue("@EndDate", p.EndDate);
                com.Parameters.AddWithValue("@Status", p.Status);

                com.Parameters.AddWithValue("@Action", "Update");
                i = com.ExecuteNonQuery();
            }
            return i;
        }
        //Method for Deleting an Employee
        public int Delete(int ID)
        {
            int i;
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand com = new SqlCommand("DeleteProject", con);
                com.CommandType = CommandType.StoredProcedure;
                com.Parameters.AddWithValue("@PId", ID);
                i = com.ExecuteNonQuery();
            }
            return i;
        }
    }
}
﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeManagement.Controllers
{
    public class FlowChartViewController : Controller
    {

        // GET: FlowChart
        public ActionResult FlowChartView(int PID=1)
        {
            TempData["ProjectId"] = PID;
            return View();
        }
    }
}
﻿using EmployeeManagement.Infrastructure;
using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeManagement.Controllers
{
    public class DesignationController : Controller
    {
        IRepository<Designation, int> repository;

        public DesignationController()
        {
            repository = new DesignationRepository();
        }
        // GET: Designation
        public ActionResult Index()
        {
            var model = repository.GetAll();
            return View(model: model);
        }

        // GET: Designation/Details/5
        public ActionResult Details(int id)
        {
            var model = repository.GetDetails(identity: id);
            return View(model: model);
        }

        // GET: Designation/Create
        public ActionResult Create()
        {
            var model = new Designation();
            return View(model: model);
        }

        // POST: Designation/Create
        [HttpPost]
        public ActionResult Create(Designation designation)
        {
            try
            {
                // TODO: Add insert logic here
                DesignationDataAccess obj = new DesignationDataAccess();
                if (ModelState.IsValid)
                {

                    //repository.CreateNew(item: designation);
                    obj.CreateDesignation(designation);
                    return RedirectToAction("Index");
                }
                else
                {

                    return View(model: designation);
                }
            }
            catch
            {
                return View(model: designation);
            }
        }

        // GET: Designation/Edit/5
        public ActionResult Edit(int id)
        {
            var model = repository.GetDetails(identity: id);
            return View(model: model);
        }

        // POST: Designation/Edit/5
        [HttpPost]
        public ActionResult Edit(Designation designation)
        {
            try
            {
                // TODO: Add update logic here
                if (ModelState.IsValid)
                {
                    repository.Update(item: designation);
                    return RedirectToAction("Index");
                }
                else
                {

                    return View(model: designation);
                }
            }
            catch
            {
                return View(model: designation);
            }
        }

        // GET: Designation/Delete/5
        public ActionResult Delete(int id)
        {
            var model = repository.GetDetails(identity: id);
            return View(model: model);
        }


        [HttpPost]
        public ActionResult DeleteConfirm(int id)
        {
            repository.Delete(id);
            return RedirectToAction("Index");
        }

    }
}
   
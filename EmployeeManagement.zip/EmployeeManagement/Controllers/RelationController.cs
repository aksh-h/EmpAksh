﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EmployeeManagement.Models;

namespace EmployeeManagement.Controllers
{
    public class RelationController : Controller
    {
        private EmployeeManagementContext db = new EmployeeManagementContext();
        private object _context;

        // GET: Relation
        public ActionResult Index()
        {
            return View(db.Relations.ToList());
        }

        // GET: Relation/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relation relation = db.Relations.Find(id);
            if (relation == null)
            {
                return HttpNotFound();
            }
            return View(relation);
        }

        // GET: Relation/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Relation/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RelationId,PId,EId,RId,Employee,Employee1,Project,EName,PName,Description,Client,Technology,StartDate,EndDate,Status")] Relation relation)
        {
            if (ModelState.IsValid)
            {
                db.Relations.Add(relation);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(relation);
        }

        // GET: Relation/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relation relation = db.Relations.Find(id);
            if (relation == null)
            {
                return HttpNotFound();
            }
            return View(relation);
        }

        // POST: Relation/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RelationId,PId,EId,RId,Employee,Employee1,Project,EName,PName,Description,Client,Technology,StartDate,EndDate,Status")] Relation relation)
        {
            if (ModelState.IsValid)
            {
                db.Entry(relation).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(relation);
        }

        // GET: Relation/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Relation relation = db.Relations.Find(id);
            if (relation == null)
            {
                return HttpNotFound();
            }
            return View(relation);
        }

        // POST: Relation/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Relation relation = db.Relations.Find(id);
            db.Relations.Remove(relation);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
        //public ActionResult ProjectList(int projectId)
        //{
        //    var roles = _context.Project.Select(p => p.pName);
        //    var viewModel = new ViewModel
        //    {
        //        ProjectList = new SelectList(Project)
        //    };
        //    return View(viewModel);
        //}

        public ActionResult ProjectRelation(int projectId, int EmpID)
        {
            var obj1 = db.Relations.FirstOrDefault(x => x.PId == projectId && x.EId == EmpID);
            if (obj1 != null)
            {
                return Json("Already Employee Added for this Project!!", JsonRequestBehavior.AllowGet);
            }
            Relation obj = new Relation();
            obj.EId = EmpID;
            obj.PId = projectId;
            db.Relations.Add(obj);
            db.SaveChanges();
            return Json("Added Success", JsonRequestBehavior.AllowGet);
        }
    }
}

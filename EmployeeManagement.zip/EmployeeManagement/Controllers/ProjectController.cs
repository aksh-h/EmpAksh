﻿using EmployeeManagement.BLL;
using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeManagement.Controllers
{
    public class ProjectController : Controller
    {
        BL bl = new BL();
        // GET: Project
        [HttpGet]
        public ActionResult Index()
        {
            List<Proj> model = bl.PopulateProjects();
            ViewBag.projects = model;
            return View(model);
        }
        [HttpGet]
        public ActionResult Submit(int id)
        {
            //string id = formcollection["ProjectID"];
            //  List<Relationship> rs = new List<Relationship>();
            // rs = bl.GetProjectDetails(id);
            //return View(rs);
            return Json(bl.GetProjectDetails(id), JsonRequestBehavior.AllowGet);

            
        }

        public JsonResult List()
        {
            return Json(bl.ListAll(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult Add(Proj p)
        {
            return Json(bl.Add(p), JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult ViewEmpById(int id)
        {
            Empl emp = bl.GetEmployee(id);
            if (emp != null)
                return Json(emp, JsonRequestBehavior.AllowGet);
            //return PartialView("Partial", emp);
            else
                return RedirectToAction("Submit");
        }

       
        public JsonResult getbyID(int ID)
        {
            var Project =bl.ListAll().Find(x => x.PId.Equals(ID));
            return Json(Project, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Update(Proj p)
        {
            return Json(bl.Update(p), JsonRequestBehavior.AllowGet);
        }
        public JsonResult Delete(int ID)
        {
            return Json(bl.Delete(ID), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Details()
        {
            return View();
        }

        public ActionResult DropDown1()
        {
            using (OfficeManagementEntities2 db = new OfficeManagementEntities2())
            {
                var result = (from role in db.Projects select role).ToList();
                if (result != null)
                {
                    ViewBag.myRoles = result.Select(N => new SelectListItem { Text = N.PName, Value = N.PId.ToString() });
                }
            }
            return View();
        }

    }
}
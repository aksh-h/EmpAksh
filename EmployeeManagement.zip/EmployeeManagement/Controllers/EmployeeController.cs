﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using EmployeeManagement.BLL;
using EmployeeManagement.Models;

namespace EmployeeManagement.Controllers
{
    public class EmployeeController : Controller
    {
        EmployeeDB empDB = new EmployeeDB();

        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult List()
        {
            return Json(empDB.ListAll(), JsonRequestBehavior.AllowGet);
        }
        public JsonResult Add(Empl emp)
        {
            return Json(empDB.Add(emp), JsonRequestBehavior.AllowGet);
        }
        public JsonResult GetbyID(int ID)
        {
            var Employee = empDB.ListAll().Find(x => x.EId.Equals(ID));
            return Json(Employee, JsonRequestBehavior.AllowGet);
        }
        public JsonResult Update(Empl emp)
        {
            return Json(empDB.Update(emp), JsonRequestBehavior.AllowGet);
        }


        // POST: Employee/Delete/ID
        public JsonResult Delete(int ID)
        {
            return Json(empDB.Delete(ID), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Designation1()
        {
            using (OfficeManagementEntities3 db = new OfficeManagementEntities3())
            {
                var result = (from skills in db.Employees select skills).ToList();
                if (result != null)
                {
                    ViewBag.mySkills = result.Select(N => new SelectListItem { Text = N.DesignationName, Value = N.EId.ToString() });
                }
            }
            return View();
        }

        // GET: Dropdown  
        public ActionResult DropDown1()
        {
            using (OfficeManagementEntities3 db = new OfficeManagementEntities3())
            {
               var result = (from skills in db.Employees select skills).ToList();
               if (result != null) 
               {
                    ViewBag.mySkills = result.Select(N => new SelectListItem { Text = N.EName, Value = N.EId.ToString() });
                }
            }
                return View();
        }

        //private static List<SelectListItem> GetDesignation()
        //{
        //    OfficeManagementEntities3 db = new OfficeManagementEntities3();
        //    List<SelectListItem> DesignationList = (from p in db.Employees.AsEnumerable()
        //                                         select new SelectListItem
        //                                         {
        //                                             Text = p.DesignationName,
        //                                             Value = p.EId.ToString()
        //                                         }).ToList();


        //    //Add Default Item at First Position.
        //    DesignationList.Insert(0, new SelectListItem { Text = "--Select DesignationName--", Value = "" });
        //    return DesignationList;
        //}

        //public ActionResult ProjectRelation(int projectId, int EmpID)
        //{
        //    var obj1 = db.Relation.FirstOrDefault(x => x.PId == projectId && x.MemberID == EmpID);
        //    if (obj1 != null)
        //    {
        //        return Json("Already Employee Added for this Project!!", JsonRequestBehavior.AllowGet);
        //    }
        //    Relation obj = new Relation();
        //    obj.EId = EmpID;
        //    obj.PId = projectId;
        //    db.Relationships.Add(obj);
        //    db.SaveChanges();
        //    return Json("Added Success", JsonRequestBehavior.AllowGet);
        //}



        //public ActionResult FlowChart()
        //{

        //    List<Employee> EmployeeList = empDB.ListAll();
        //    var query=EmployeeList.Where(x=>x)
        //    return Json(empDB.ListAll(),JsonRequestBehavior.AllowGet);
        //}
        //BL p1 = new BL();
        //[HttpGet]
        //public ActionResult FlowChart()
        //{
        //    List<Project> model = p1.PopulateProjects();
        //    ViewBag.projects = model;
        //    return View(model);
        //}
        //[HttpPost]
        //public ActionResult FlowChart(int id)
        //{
        //    //string id = formcollection["ProjectID"];
        //    //  List<Relationship> rs = new List<Relationship>();
        //    // rs = bl.GetProjectDetails(id);
        //    //return View(rs);
        //    return Json(p1.GetProjectDetails(id), JsonRequestBehavior.AllowGet);



    }
    //public JsonResult GetEmployee()
    //{
    //    var DbResult = db.Employees.ToList();

    //    return Json(DbResult, JsonRequestBehavior.AllowGet);
    //}
}

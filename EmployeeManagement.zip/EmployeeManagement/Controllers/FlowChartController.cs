﻿using EmployeeManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace EmployeeManagement.Controllers
{
    public class FlowChartController : ApiController
    {
        EmployeeDB empDB = new EmployeeDB();
        


        // GET: api/FlowChart/5
        public List<string> Get(int id)
        {
            return empDB.FlowChart(id);
        }

        // POST: api/FlowChart
        public void Post([FromBody]string value)
        {
        }

        // PUT: api/FlowChart/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/FlowChart/5
        public void Delete(int id)
        {
        }
    }
}

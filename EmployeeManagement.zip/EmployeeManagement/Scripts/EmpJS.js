﻿
//<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
//    <script>
//        $(document).ready(function(){
//            $( "#myInput" ).on( "keyup", function () {
//                var value = $( this ).val().toLowerCase();
//                $( "#myTable tr" ).filter( function () {
//                    $( this ).toggle( $( this ).text().toLowerCase().indexOf( value ) > -1 )
//                } );
//            } );
//        });
//</script>
$( document ).ready( function () {
    $( "#myInput" ).on( "keyup", function () {
        var value = $( this ).val().toLowerCase();
        $( "#myTable tr" ).filter( function () {
            $( this ).toggle( $( this ).text().toLowerCase().indexOf( value ) > -1 )
        } );
    } );
    loadData();
} );
    

//$( document ).ready( function () {
//    loadData();
   
//});
//Load Data function
function loadData() {
    $.ajax({
        url: "/Employee/List",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            var html = '';
            console.log( result );
            $.each( result, function ( key, item ) {
               
                html += '<tr>';
                html += '<td>' + item.EId + '</td>';
                html += '<td>' + item.EName + '</td>';
                html += '<td>' + item.DesignationName + '</td>';
                html += '<td>' + item.Email + '</td>';
                html += '<td>' + item.PhoneNo + '</td>';
                html += '<td>' + item.Status + '</td>';
                html += '<td>' + item.ManagerId + '</td>';
              
                html += '<td><a /*class="text-light" style="color:red"*/ href="#" onclick="return getbyID(' + item.EId + ')">Edit</a> | <a /*class="text-light" style="color:red"*/ href="#" onclick="Delete(' + item.EId + ')">Delete</a></td>';
                html += '</tr>';
            });
            $('.tbody').html(html);
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

//Add Data Function
function Add() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        EId: $('#EId').val(),
        EName: $('#EName').val(),
        
        DesignationName: $('#DesignationName').val(),
               
        Email: $( '#Email' ).val(),
        
        PhoneNo: $('#PhoneNo').val(),
        Status: $('#Status').val(),
        ManagerId: $('#ManagerId').val(),
       
        
    };
    $.ajax({
        url: "/Employee/Add",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#myModal').modal('hide');
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}
//Function for getting the Data Based upon Employee ID
function getbyID(EId) {
    $('#EName').css('border-color', 'lightgrey');
   
    $('#DesignationName').css('border-color', 'lightgrey');
    
    $('#Email').css('border-color', 'lightgrey');
    $('#PhoneNo').css('border-color', 'lightgrey');
    $('#Status').css('border-color', 'lightgrey');
    $('#ManagerId').css('border-color', 'lightgrey');
   
    $.ajax({
        url: "/Employee/getbyID/" + EId,
        typr: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function (result) {
            $('#EId').val(result.EId);
            $('#EName').val(result.EName);
         
            $('#DesignationName').val(result.DesignationName);
          
            $('#Email').val(result.Email);
            $('#PhoneNo').val(result.PhoneNo);
            $('#Status').val(result.Status);
            $('#ManagerId').val(result.ManagerId);
        
            $('#myModal').modal('show');
            $('#btnUpdate').show();
            $('#btnAdd').hide();
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
    return false;
}
//function for updating employee's record
function Update() {
    var res = validate();
    if (res == false) {
        return false;
    }
    var empObj = {
        EId: $('#EId').val(),
        EName: $('#EName').val(),
   
        DesignationName: $('#DesignationName').val(),
   
        Email: $( '#Email' ).val(),
        
        PhoneNo: $('#PhoneNo').val(),
        Status: $('#Status').val(),
        ManagerId: $('#ManagerId').val(),
     
    };

    $.ajax({
        url: "/Employee/Update",
        data: JSON.stringify(empObj),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function (result) {
            loadData();
            $('#myModal').modal('hide');
            $('#EId').val("");
            $('#EName').val("");
            
            $('#DesignationName').val("");
           
            $('#Email').val("");
            $('#PhoneNo').val("");
            $('#Status').val("");
            $('#ManagerId').val("");
        
        },
        error: function (errormessage) {
            alert(errormessage.responseText);
        }
    });
}

    //function for deleting employee's record
    function Delete(ID) {
        var ans = confirm("Are you sure you want to delete this Record?");
        if (ans) {
            $.ajax({
                url: "/Employee/Delete/" + ID,
                type: "POST",
                contentType: "application/json;charset=UTF-8",
                dataType: "json",
                success: function (result) {
                    loadData();
                },
                error: function (errormessage) {
                    alert(errormessage.responseText);
                }
            });
        }
    }





    //Function for clearing the textboxes
    function clearTextBox() {
        $('#EId').val("");
        $('#EName').val("");
        $('#DesignationName').val("");
        $('#Email').val("");
        $('#PhoneNo').val("");
        $('#Status').val("");
        $('#ManagerId').val("");
       
        $('#btnUpdate').hide();
        $('#btnAdd').show();
        $('#EName').css('border-color', 'lightgrey');
       
        $('#DesignationName').css('border-color', 'lightgrey');
       
        $('#Email').css('border-color', 'lightgrey');
        $('#PhoneNo').css('border-color', 'lightgrey');
        $('#Status').css('border-color', 'lightgrey');
        $('#ManagerId').css('border-color', 'lightgrey');
        
    }


    ////Valdidation using jquery
    function validate() {
        var isValid = true;
        console.log( $( '#EName' ).val());
        if ($('#EName').val().trim() == "") {
            $('#EName').css('border-color', 'Red');
            $( '#EName' ).after( '<span class="col-md-offset-3">EmployeeName is required</span>').css('text-color','Red');
            $( '#EName' ).after( [StringLength( 20, ErrorMessage = "Employee Name cannot exceed 20 chars." )]
                              [RegularExpression("^[a-zA-Z]*$", ErrorMessage = "Only Alphabets are allowed.")])
            isValid = false;
        }
        else {
            $( '#EName' ).css( 'border-color', 'lightgrey');
        }
        

        if ( $( '#DesignationName' ).val().trim() == "" ) {
            $( '#DesignationName' ).css( 'border-color', 'Red' );
            $( '#DesignationName' ).after( '<span class="error">DesignationName is required</span>' );
            isValid = false;
        }
        else {
            $( '#DesignationName' ).css( 'border-color', 'lightgrey' );
        }


        if ($('#Email').val().trim() == "") {
            $('#Email').css('border-color', 'Red');
            $( '#Email' ).after( '<span class="error">Email is required</span>' );
            isValid = false;
        }
        else {
            $('#Email').css('border-color', 'lightgrey');
        }

        if ($('#PhoneNo').val().trim() == "") {
            $('#PhoneNo').css('border-color', 'Red');
            $( '#PhoneNo' ).after( '<span class="error">PhoneNo is required</span>' );
            isValid = false;
        }
        else {
            $('#PhoneNo').css('border-color', 'lightgrey');
        }


        if ( $( '#Status' ).val().trim() == "" ) {
            $( '#Status' ).css( 'border-color', 'Red' );
            $( '#Status' ).after( '<span class="error">Status is required</span>' );
            isValid = false;
        }
        else {
            $( '#Status' ).css( 'border-color', 'lightgrey' );
        }


        if ( $( '#ManagerId' ).val().trim() == "" ) {
            $( '#ManagerId' ).css( 'border-color', 'Red');

        
            $( '#ManagerId' ).after( '<span class="error">ManagerId is required</span>' );
         
            isValid = false;
        }
        else {
            $( '#ManagerId' ).css( 'border-color', 'lightgrey' );
        }

        
        return isValid;
    }



    //$(document).ready(function () {
    //    $("#btnAdd").click( function () {
    //        $.ajax( {
    //            type: "get",
    //            url: 'Add',
    //            contentType: "application/json; charset=utf-8",
    //            data: {'':EId,EName,DesignationId,},
    //            datatype: "json",
    //            success: function ( data ) {


    //            },
    //            error: function () {
    //                alert( "Check IN Failed." );
    //            }
    //        } );


    //    } );
    //    } );
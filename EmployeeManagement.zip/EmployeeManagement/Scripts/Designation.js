﻿$( document ).ready( function () {
    $( "#myInput" ).on( "keyup", function () {
        var value = $( this ).val().toLowerCase();
        $( "#myTable tr" ).filter( function () {
            $( this ).toggle( $( this ).text().toLowerCase().indexOf( value ) > -1 )
        } );
    } );
    loadData();
} );

function loadData() {
    $.ajax( {
        url: "/Designation/List",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function ( result ) {
            var html = '';
            console.log( result );
            $.each( result, function ( key, item ) {

                html += '<tr>';
                html += '<td>' + item.DesignationId + '</td>';
              
                html += '<td>' + item.DesignationName + '</td>';
                html += '<td>' + item.Status + '</td>';
                html += '<td><a /*class="text-light" style="color:red"*/ href="#" onclick="return getbyID(' + item.DesignationId + ')">Edit</a> | <a /*class="text-light" style="color:red"*/ href="#" onclick="Delete(' + item.DesignationId + ')">Delete</a></td>';
                html += '</tr>';
            } );
            $( '.tbody' ).html( html );
        },
        error: function ( errormessage ) {
            alert( errormessage.responseText );
        }
    } );
}
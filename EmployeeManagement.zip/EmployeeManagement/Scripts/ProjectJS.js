﻿$( document ).ready( function () {
    $( "#myInput" ).on( "keyup", function () {
        var value = $( this ).val().toLowerCase();
        $( "#myTable tr" ).filter( function () {
            $( this ).toggle( $( this ).text().toLowerCase().indexOf( value ) > -1 )
        } );
    } );
    loadData();
} );
//Load Data function
function loadData() {
    $.ajax( {
        url: "/Project/List",
        type: "GET",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function ( result ) {
            var html = '';

            $.each( result, function ( key, item ) {

                html += '<tr>';
                html += '<td>' + item.PId + '</td>';
                html += '<td>' + item.PName + '</td>';
                html += '<td>' + item.Description + '</td>';
                html += '<td>' + item.Client + '</td>';
                html += '<td>' + item.Technology + '</td>';
                //html += '<td>' + item.StartDate+ '</td>';
                //html += '<td>' + item.EndDate + '</td>';
                html += '<td>' + item.Status + '</td>';

                html += '<td><a /*class="text-light" style="color:red"*/ href="#" onclick="return getbyID(' + item.PId + ')">Edit</a> | <a /*class="text-light" style="color:red"*/ href="#" onclick="Delete(' + item.PId + ')">Delete</a></td>';
                html += '</tr>';
            } );
            $( '.tbody' ).html( html );
        },
        error: function ( errormessage ) {
            alert( errormessage.responseText );
        }
    } );
}

//Add Data Function
function Add() {
    var res = validate();
    if ( res == false ) {
        return false;
    }
    var empObj = {
        PId: $( '#PId' ).val(),
        PName: $( '#PName' ).val(),

        Description: $( '#Description' ).val(),

        Client: $( '#Client' ).val(),

        Technology: $( '#Technology' ).val(),
        //StartDate: $( '#StartDate' ).val(),
        //EndDate: $( '#EndDate' ).val(),
        Status: $( '#Status' ).val(),


    };
    $.ajax( {
        url: "/Project/Add",
        data: JSON.stringify( empObj ),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function ( result ) {
            loadData();
            $( '#myModal' ).modal( 'hide' );
        },
        error: function ( errormessage ) {
            alert( errormessage.responseText );
        }
    } );
}
//Function for getting the Data Based upon Employee ID
function getbyID( PId ) {
    $( '#PName' ).css( 'border-color', 'lightgrey' );

    $( '#Description' ).css( 'border-color', 'lightgrey' );

    $( '#Client' ).css( 'border-color', 'lightgrey' );
    $( '#Technology' ).css( 'border-color', 'lightgrey' );
    //$( '#StartDate' ).css( 'border-color', 'lightgrey' );
    //$( '#EndDate' ).css( 'border-color', 'lightgrey' );
    $( '#Status' ).css( 'border-color', 'lightgrey' );


    $.ajax( {
        url: "/Project/getbyID/" + PId,
        typr: "GET",
        contentType: "application/json;charset=UTF-8",
        dataType: "json",
        success: function ( result ) {
            $( '#PId' ).val( result.PId );
            $( '#PName' ).val( result.PName );

            $( '#Description' ).val( result.Description );
            $( '#Client' ).val( result.Client );
            $( '#Technology' ).val( result.Technology );
            //$( '#StartDate' ).val( result.StartDate );
            //$( '#EndDate' ).val( result.EndDate );

            $( '#Status' ).val( result.Status );
           

            $( '#myModal' ).modal( 'show' );
            $( '#btnUpdate' ).show();
            $( '#btnAdd' ).hide();
        },
        error: function ( errormessage ) {
            alert( errormessage.responseText );
        }
    } );
    return false;
}
//function for updating employee's record
function Update() {
    var res = validate();
    if ( res == false ) {
        return false;
    }
    var empObj = {
        PId: $( '#PId' ).val(),
        PName: $( '#PName' ).val(),
        Description: $( '#Description' ).val(),
        Client: $( '#Client' ).val(),
        Technology: $( '#Technology' ).val(),

        //StartDate: $( '#StartDate' ).val(),
        //EndDate: $( '#EndDate' ).val(),
        Status: $( '#Status' ).val(),

    };

    $.ajax( {
        url: "/Project/Update",
        data: JSON.stringify( empObj ),
        type: "POST",
        contentType: "application/json;charset=utf-8",
        dataType: "json",
        success: function ( result ) {
            loadData();
            $( '#myModal' ).modal( 'hide' );
            $( '#PId' ).val( "" );
            $( '#PName' ).val( "" );
            $( '#Description' ).val( "" );
            $( '#Client' ).val( "" );
            $( '#Technology' ).val( "" );
            //$( '#StartDate' ).val( "" );
            //$( '#EndDate' ).val( "" );
            $( '#Status' ).val( "" );
           
        },
        error: function ( errormessage ) {
            alert( errormessage.responseText );
        }
    } );
}

//function for deleting employee's record
function Delete( ID ) {
    var ans = confirm( "Are you sure you want to delete this Record?" );
    if ( ans ) {
        $.ajax( {
            url: "/Project/Delete/" + ID,
            type: "POST",
            contentType: "application/json;charset=UTF-8",
            dataType: "json",
            success: function ( result ) {
                loadData();
            },
            error: function ( errormessage ) {
                alert( errormessage.responseText );
            }
        } );
    }
}

//Function for clearing the textboxes
function clearTextBox() {
    $( '#PId' ).val( "" );
    $( '#PName' ).val( "" );
    $( '#Description' ).val( "" );
    $( '#Client' ).val( "" );
    $( '#Technology' ).val( "" );
    //$( '#StartDate' ).val( "" );
    //$( '#EndDate' ).val( "" );
    $( '#Status' ).val( "" );
    

    $( '#btnUpdate' ).hide();
    $( '#btnAdd' ).show();
    $( '#PName' ).css( 'border-color', 'lightgrey' );

    $( '#Description' ).css( 'border-color', 'lightgrey' );

    $( '#Client' ).css( 'border-color', 'lightgrey' );
    $( '#Technology' ).css( 'border-color', 'lightgrey' );
    //$( '#StartDate' ).css( 'border-color', 'lightgrey' );
    //$( '#EndDate' ).css( 'border-color', 'lightgrey' );
    $( '#Status' ).css( 'border-color', 'lightgrey' );
   

}


////Valdidation using jquery
function validate() {
    var isValid = true;
    console.log( $( '#PName' ).val() );
    if ( $( '#PName' ).val().trim() == "" ) {
        $( '#PName' ).css( 'border-color', 'Red' );
        $( '#PName' ).after( '<span class="error">Project Name is required</span>' );
        $( '#PName' ).after( [StringLength( 20, ErrorMessage = "Project Name cannot exceed 20 chars." )]
        [RegularExpression( "^[a-zA-Z]*$", ErrorMessage = "Only Alphabets are allowed." )] )
        isValid = false;
    }
    else {
        $( '#PName' ).css( 'border-color', 'lightgrey' );
    }


    if ( $( '#Description' ).val().trim() == "" ) {
        $( '#Description' ).css( 'border-color', 'Red' );
        $( '#Description' ).after( '<span class="error">Description is required</span>' );
        isValid = false;
    }
    else {
        $( '#Description' ).css( 'border-color', 'lightgrey' );
    }


    if ( $( '#Client' ).val().trim() == "" ) {
        $( '#Client' ).css( 'border-color', 'Red' );
        $( '#Client' ).after( '<span class="error">Client is required</span>' );
        isValid = false;
    }
    else {
        $( '#Client' ).css( 'border-color', 'lightgrey' );
    }

    if ( $( '#Technology' ).val().trim() == "" ) {
        $( '#Technology' ).css( 'border-color', 'Red' );
        $( '#Technology' ).after( '<span class="error">Technology is required</span>' );
        isValid = false;
    }
    else {
        $( '#Technology' ).css( 'border-color', 'lightgrey' );
    }


    //if ( $( '#StartDate' ).val().trim() == "" ) {
    //    $( '#StartDate' ).css( 'border-color', 'Red' );


    //    $( '#StartDate' ).after( '<span class="error">StartDate is required</span>' );

    //    isValid = false;
    //}
    //else {
    //    $( '#StartDate' ).css( 'border-color', 'lightgrey' );
    //}


    //if ( $( '#EndDate' ).val().trim() == "" ) {
    //    $( '#EndDate' ).css( 'border-color', 'Red' );


    //    $( '#EndDate' ).after( '<span class="error">EndDate is required</span>' );

    //    isValid = false;
    //}
    //else {
    //    $( '#EndDate' ).css( 'border-color', 'lightgrey' );
    //}



    if ( $( '#Status' ).val().trim() == "" ) {
        $( '#Status' ).css( 'border-color', 'Red' );
        $( '#Status' ).after( '<span class="error">Status is required</span>' );
        isValid = false;
    }
    else {
        $( '#Status' ).css( 'border-color', 'lightgrey' );
    }



    return isValid;
}



    //$(document).ready(function () {
    //    $("#btnAdd").click( function () {
    //        $.ajax( {
    //            type: "get",
    //            url: 'Add',
    //            contentType: "application/json; charset=utf-8",
    //            data: {'':EId,EName,DesignationId,},
    //            datatype: "json",
    //            success: function ( data ) {


    //            },
    //            error: function () {
    //                alert( "Check IN Failed." );
    //            }
    //        } );


    //    } );
    //    } );